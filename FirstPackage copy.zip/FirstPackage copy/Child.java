package FirstPackage;

class Parent {
	public int i;
	private int j;
	protected int k;
    public void DisplayData(){
    	i=10;
    	j=20;
    	k=30;
    	System.out.println("In Parent");
    	System.out.println("I is"+i);
    	System.out.println("J is"+j);
    	System.out.println("K is"+k);
    }

}
public class Child extends Parent
{
	int m;
	public void display()
	{
		m=40;
		i=20;
		System.out.println("In Child ");
		System.out.println("m is"+m);
		System.out.println("I is"+i);
	}
	public static void main(String[] args)
	{
		Child c1= new Child();
		c1.DisplayData();
		c1.display();
	}
}