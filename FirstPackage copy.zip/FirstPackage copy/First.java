package FirstPackage;

import java.util.Scanner;

public class First {
	public int a;
	public int b;
	public int c;
	Scanner scan;
}

public class Second extends First {
	scan=new Scanner();System.out.println("Enter the value of a");a=scan.nextInt(a);System.out.println("Enter the value of b");b=scan.nextInt(b);System.out.println("Enter the value of c");c=scan.nextInt(c);
	public void greatest(){
		
	if(a>b&&a>c){
		System.out.println("a is greatest");
	}
	else if(b>c&&b>a)
	{
		System.out.println("b is greatest");
	}
	else
	{
		System.out.println("c is greatest");
	}
}
}

public class Third extends Second{
	public static void main(String[] args){
	
Third third = new Third();
third.greatest();
	

}
}
