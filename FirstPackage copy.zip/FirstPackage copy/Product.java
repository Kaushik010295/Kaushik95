package FirstPackage;

public class Product {
	int price, qty;
	String prodName;
	public int getPrice() {
		return price;
	}


	public void setPrice(int price) {
		this.price = price;
	}


	public int getQty() {
		return qty;
	}


	public void setQty(int qty) {
		this.qty = qty;
	}


	public String getProdName() {
		return prodName;
	}


	public void setProdName(String prodName) {
		this.prodName = prodName;

	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
Product p1=new Product();
Product p2=new Product();
p1.setPrice(100);
p1.setQty(10);
p1.setProdName("Mobiles");
p2.setPrice(200);
p2.setQty(5);
p2.setProdName("Laptops");
System.out.println(p1.getPrice());
System.out.println(p1.getProdName());
System.out.println(p1.getQty());
System.out.println(p2.getPrice());
System.out.println(p2.getProdName());
System.out.println(p2.getQty());


	}
}
