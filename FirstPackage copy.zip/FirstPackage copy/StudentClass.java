package FirstPackage;

public class StudentClass {
	//variable declaration 
	int studentId;
	String studentName;
	String course;
	public void showData(){
		studentId=1234;
		studentName="Kaushik";
		course="java";
		System.out.println("Below are the student details-");
		System.out.println("Student id : "+ studentId);
		System.out.println("Student Name : " + studentName);
		System.out.println("Course: " + course);
	}
	
	

	public static void main(String[] args) {
		StudentClass c1=new StudentClass();
		c1.showData();
	}

}
